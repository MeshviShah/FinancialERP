const express = require('express');
const { getClientController, getAllClientController, updateClientController, deleteClientController, creatClientController } = require('../controller/client.controller');
const { clientValidator } = require('../validators/client.validators');


const ClientRouter  = express.Router();

//Client Router
ClientRouter.post("/" ,clientValidator,creatClientController);                  //Creat Client 
ClientRouter.get("/:id",getClientController)                     //Get Client By Id             
ClientRouter.get("/",getAllClientController)                     //Get All Clients
ClientRouter.put("/:id",updateClientController)                  //Update Client By Id
ClientRouter.delete("/:id",deleteClientController)               //Delete Client By Id


module.exports = ClientRouter;