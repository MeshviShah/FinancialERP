const express = require('express');
const { getFirmController, getAllFirmController, updateFirmController, deleteFirmController, creatFirmController } = require('../controller/firm.controller');
const { firmValidator } = require('../validators/firm.validators');


const FirmRouter  = express.Router();

//Firm Router
FirmRouter.post("/" ,firmValidator, creatFirmController);               //Add Firm
FirmRouter.get("/:id",getFirmController)                 //Get Firm By ID
FirmRouter.get("/",getAllFirmController)                 //Get All Firm
FirmRouter.put("/:id",updateFirmController)              //Update Firm By Id
FirmRouter.delete("/:id",deleteFirmController)           //Delete Firm By Id


module.exports = FirmRouter;