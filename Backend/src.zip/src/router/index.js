//const ClientRouter = require("./client.router")
const AuthRouter = require("./auth.router")
const ClientRouter = require("./client.router")
const DocumentRouter = require("./document.router")
const EventRouter = require("./event.router")
const Event_TypeRouter = require("./event_type.router")
const FirmRouter = require("./firm.router")
const RoleRouter = require("./role.router")
const ServiceRouter = require("./service.router")
const Service_categoryRouter = require("./service_category.router")
const TaskRouter = require("./task.router")
const Task_statusRouter = require("./task_status.router")
const UserRouter = require("./user.router")


const router  = (app) => {
    app.use('/user',UserRouter)                                          //User
    app.use('/firm',FirmRouter)                                          //Firm
    app.use('/role',RoleRouter)                                          //Role
    app.use('/event_type',Event_TypeRouter) 
    app.use('/event',EventRouter) 
    app.use('/task_status',Task_statusRouter) 
    app.use('/task',TaskRouter) 
     app.use('/service_category',Service_categoryRouter) 
    app.use('/service',ServiceRouter) 
     app.use('/document',DocumentRouter) 
    app.use('/client',ClientRouter) 
    app.use("/",AuthRouter)
}

module.exports = router