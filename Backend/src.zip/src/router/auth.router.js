const express = require('express');
const { getAuthController, getAllAuthController, updateAuthController, deleteAuthController, creatAuthController, registerController, loginController } = require('../controller/Auth.controller');



const AuthRouter  = express.Router();

//Auth Router
AuthRouter.post("/register" , registerController );                  //Creat Auth 
AuthRouter.post("/login" , loginController );  


module.exports = AuthRouter;