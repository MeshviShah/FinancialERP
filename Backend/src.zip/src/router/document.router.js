const express = require('express');
const { getDocumentController, getAllDocumentController, updateDocumentController, deleteDocumentController, creatDocumentController } = require('../controller/document.controller');


const DocumentRouter  = express.Router();

//Document Router
DocumentRouter.post("/" , creatDocumentController);                  //Creat Document 
DocumentRouter.get("/:id",getDocumentController)                     //Get Document By Id             
DocumentRouter.get("/",getAllDocumentController)                     //Get All Documents
DocumentRouter.put("/:id",updateDocumentController)                  //Update Document By Id
DocumentRouter.delete("/:id",deleteDocumentController)               //Delete Document By Id


module.exports = DocumentRouter;