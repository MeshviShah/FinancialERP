const express = require('express');
const { getEvent_TypeController, getAllEvent_TypeController, updateEvent_TypeController, deleteEvent_TypeController, creatEvent_TypeController } = require('../controller/event_type.controller');


const Event_TypeRouter  = express.Router();

//Event_Type Router
Event_TypeRouter.post("/" , creatEvent_TypeController);                  //Creat Event_Type 
Event_TypeRouter.get("/:id",getEvent_TypeController)                     //Get Event_Type By Id             
Event_TypeRouter.get("/",getAllEvent_TypeController)                     //Get All Event_Types
Event_TypeRouter.put("/:id",updateEvent_TypeController)                  //Update Event_Type By Id
Event_TypeRouter.delete("/:id",deleteEvent_TypeController)               //Delete Event_Type By Id


module.exports = Event_TypeRouter;