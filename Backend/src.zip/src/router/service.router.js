const express = require('express');
const { getServiceController, getAllServiceController, updateServiceController, deleteServiceController, creatServiceController } = require('../controller/service.controller');
const { serviceValidator } = require('../validators/service.validators');


const ServiceRouter  = express.Router();

//Service Router
ServiceRouter.post("/", serviceValidator , creatServiceController);                  //Creat Service 
ServiceRouter.get("/:id",getServiceController)                     //Get Service By Id             
ServiceRouter.get("/",getAllServiceController)                     //Get All Services
ServiceRouter.put("/:id",updateServiceController)                  //Update Service By Id
ServiceRouter.delete("/:id",deleteServiceController)               //Delete Service By Id


module.exports = ServiceRouter;