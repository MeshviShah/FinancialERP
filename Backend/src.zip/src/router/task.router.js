const express = require('express');
const { getTaskController, getAllTaskController, updateTaskController, deleteTaskController, creatTaskController } = require('../controller/task.controller');
const { taskValidator } = require('../validators/task.validatos');


const TaskRouter  = express.Router();

//Task Router
TaskRouter.post("/" ,taskValidator, creatTaskController);                  //Creat Task 
TaskRouter.get("/:id",getTaskController)                     //Get Task By Id             
TaskRouter.get("/",getAllTaskController)                     //Get All Tasks
TaskRouter.put("/:id",updateTaskController)                  //Update Task By Id
TaskRouter.delete("/:id",deleteTaskController)               //Delete Task By Id


module.exports = TaskRouter;