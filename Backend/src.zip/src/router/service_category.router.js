const express = require('express');
const { getService_categoryController, getAllService_categoryController, updateService_categoryController, deleteService_categoryController, creatService_categoryController } = require('../controller/service_category.controller');


const Service_categoryRouter  = express.Router();

//Service_category Router
Service_categoryRouter.post("/" , creatService_categoryController);                  //Creat Service_category 
Service_categoryRouter.get("/:id",getService_categoryController)                     //Get Service_category By Id             
Service_categoryRouter.get("/",getAllService_categoryController)                     //Get All Service_categorys
Service_categoryRouter.put("/:id",updateService_categoryController)                  //Update Service_category By Id
Service_categoryRouter.delete("/:id",deleteService_categoryController)               //Delete Service_category By Id


module.exports = Service_categoryRouter;