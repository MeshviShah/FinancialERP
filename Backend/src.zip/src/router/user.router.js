const express = require('express');
const { creatUserController, getUserController, getAllUserController, updateUserController, deleteUserController } = require('../controller/user.controller');
const { userValidator } = require('../validators/user.validators');


const UserRouter  = express.Router();

UserRouter.post("/" ,userValidator , creatUserController);
UserRouter.get("/:id", getUserController)
UserRouter.get("/",getAllUserController)
UserRouter.put("/:id",updateUserController)
UserRouter.delete("/:id",deleteUserController)


module.exports = UserRouter;

