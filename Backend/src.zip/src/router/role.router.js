const express = require('express');
const { getRoleController, getAllRoleController, updateRoleController, deleteRoleController, creatRoleController } = require('../controller/role.controller');
const { roleValidator } = require('../validators/role.validators');


const RoleRouter  = express.Router();

//Role Router
RoleRouter.post("/" ,roleValidator , creatRoleController);                  //Creat Role 
RoleRouter.get("/:id",getRoleController)                     //Get Role By Id             
RoleRouter.get("/",getAllRoleController)                     //Get All Roles
RoleRouter.put("/:id",updateRoleController)                  //Update Role By Id
RoleRouter.delete("/:id",deleteRoleController)               //Delete Role By Id


module.exports = RoleRouter;