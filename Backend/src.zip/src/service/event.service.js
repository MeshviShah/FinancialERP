const EventModel = require("../models/event.models")
 const mongoose = require('mongoose');
 const { ObjectId } = mongoose.Types;
exports.CreatEventService = async(data) =>{ 
        const result = await EventModel.create(data);                              //Creat Event Query
        return result   
   
}
exports.getEventService = async(id) =>{
     
        const result = await EventModel.aggregate([
        {
          $match: {
            _id: new ObjectId(id)
        }
        },
   
    {
     
      $lookup: {
        from: "event_types",
        localField: "event_type",
        foreignField: "_id",
        as: "event_type"
      }
    },
    
    
    
  ])                             //Find Event By Id Query
         return result        
   
}
exports.getAllEventService = async() =>{
   
        const result = await EventModel.aggregate([
   
    {
     
      $lookup: {
        from: "event_types",
        localField: "event_type",
        foreignField: "_id",
        as: "event_type"
      }
    },
    
    
    
  ])                                                       //Find All Event Query
         return result        
   
}

exports.updateEventService = async(data,id) =>{
     
        const result = await EventModel.findByIdAndUpdate(data,id);              //Update Event By Id Query
          return result     
}

exports.deleteEventService = async(id) =>{
     
        const result = await EventModel.findByIdAndDelete(id);                 //Delete Event By Id Query
         return result    
}