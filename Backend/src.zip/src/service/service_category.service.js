const Service_categoryModel = require("../models/service_category.model")

exports.CreatService_categoryService = async(data) =>{ 
        const result = await Service_categoryModel.create(data);                   //Creat Service Query
        return result   
   
}
exports.getService_categoryService = async(id) =>{
     
        const result = await Service_categoryModel.findById(id);                  //Get Service_category By Id QUery
         return result         
   
}
exports.getAllService_categoryService = async() =>{
   
        const result = await Service_categoryModel.find();                      //Get All Service_category Query
         return result        
   
}

exports.updateService_categoryService = async(data,id) =>{
     
        const result = await Service_categoryModel.findByIdAndUpdate(data,id);    //Update Service_cateogry By Id Query
          return result     
}

exports.deleteService_categoryService = async(id) =>{
     
        const result = await Service_categoryModel.findByIdAndDelete(id);        //Delete Service_category By Id Query
         return result    
}