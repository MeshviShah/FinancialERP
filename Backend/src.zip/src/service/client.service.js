const ClientModel = require("../models/client.model")
 const mongoose = require('mongoose');
 const { ObjectId } = mongoose.Types;

exports.CreatClientService = async(data) =>{ 
        const result = await ClientModel.create(data);                          //Creat Client Query
        return result   
   
}
exports.getClientService = async(id) =>{
     
        const result = await ClientModel.aggregate([
        {
          $match: {
            _id: new ObjectId(id)
        }
        },
   
    {
     
      $lookup: {
        from: "users",
        localField: "ca_id",
        foreignField: "_id",
        as: "CA"
      }
    },
    
     {
     
      $lookup: {
        from: "firms",
        localField: "firm_id",
        foreignField: "_id",
        as: "firm"
      }
    },
     {
     
      $lookup: {
        from: "services",
        localField: "service_id",
        foreignField: "_id",
        as: "service"
      }
    },
    
  ])                              //Get Client By Id Query
         return result        
   
}
exports.getAllClientService = async() =>{
   
        const result = await ClientModel.find();                               //Get All Client Query
         return result        
   
}

exports.updateClientService = async(data,id) =>{
     
        const result = await ClientModel.findByIdAndUpdate(data,id);          //Update Client By Id Query
          return result     
}

exports.deleteClientService = async(id) =>{
     
        const result = await ClientModel.findByIdAndDelete(id);              //Delete Client By ID query
         return result    
}