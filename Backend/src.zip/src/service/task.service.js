const TaskModel = require("../models/task.models")
const mongoose = require('mongoose');
 const { ObjectId } = mongoose.Types;
exports.CreatTaskService = async(data) =>{ 
        const result = await TaskModel.create(data);                                  //Creat Task Query
        return result   
   
}
exports.getTaskService = async(id) =>{
     
        const result = await TaskModel.aggregate([
        {
          $match: {
            _id: new ObjectId(id)
        }
        },
   
    {
     
      $lookup: {
        from: "task_status",
        localField: "task_status",
        foreignField: "_id",
        as: "task_status"
      }
    },
    
      {
     
      $lookup: {
        from: "users",
        localField: "user_id",
        foreignField: "_id",
        as: "user"
      }
    },
    
    
  ])                                   //Get Task By Id Query
         return result        
   
}
exports.getAllTaskService = async() =>{
   
        const result = await TaskModel.aggregate([
      
   
    {
     
      $lookup: {
        from: "task_status",
        localField: "task_status",
        foreignField: "_id",
        as: "task_status"
      }
    },
    
      {
     
      $lookup: {
        from: "users",
        localField: "user_id",
        foreignField: "_id",
        as: "user"
      }
    },
    
    
  ])                                                //Get All Task Query
         return result        
   
}

exports.updateTaskService = async(data,id) =>{
     
        const result = await TaskModel.findByIdAndUpdate(data,id);                //Update Task By Id Query
          return result     
}

exports.deleteTaskService = async(id) =>{
     
        const result = await TaskModel.findByIdAndDelete(id);                    //Delete Task By Id Query
         return result    
}