const RoleModel = require("../models/role.model")

exports.CreatRoleService = async(data) =>{ 
        const result = await RoleModel.create(data);                          //Creat Role Query
        return result   
   
}
exports.getRoleService = async(id) =>{
     
        const result = await RoleModel.findById(id);                         //Get Role By Id Query
         return result        
   
}
exports.getAllRoleService = async() =>{
   
        const result = await RoleModel.find();                              //Get All Role Query
        return result        
   
}

exports.updateRoleService = async(data,id) =>{
     
        const result = await RoleModel.findByIdAndUpdate(data,id);         //Update Role By ID Query
          return result     
}

exports.deleteRoleService = async(id) =>{
     
        const result = await RoleModel.findByIdAndDelete(id);             //Delete Role By Id Query
         return result    
}