const FirmModel = require("../models/firm.model")

exports.CreatFirmService = async(data) =>{ 

        const result = await FirmModel.create(data);                             //Creat Firm Query
        return result   
   
}
exports.getFirmService = async(id) =>{
     
        const result = await FirmModel.findById(id);                            //Get Firm By Id Query
         return result        
   
}
exports.getAllFirmService = async() =>{
   
        const result = await FirmModel.find();                                 //Get All Firm Query 
         return result        
   
}

exports.updateFirmService = async(data,id) =>{
     
        const result = await FirmModel.findByIdAndUpdate(data,id);            //Update Firm Query
          return result     
}

exports.deleteFirmService = async(id) =>{
     
        const result = await FirmModel.findByIdAndDelete(id);                //Delete Firm By Id Query
         return result    
}