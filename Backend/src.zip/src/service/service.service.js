const ServiceModel = require("../models/service.model")

exports.CreatServiceService = async(data) =>{ 
        const result = await ServiceModel.create(data);                           //Creat Service Query
        return result   
   
}
exports.getServiceService = async(id) =>{                                       //Get Service By Id Query
     
        const result = await ServiceModel.aggregate([
        {
          $match: {
            _id: new ObjectId(id)
        }
        },
   
    {
     
      $lookup: {
        from: "service_categorys",
        localField: "category_id",
        foreignField: "_id",
        as: "category"
      }
    },
    
    
    
  ])             
         return result        
   
}
exports.getAllServiceService = async() =>{                                      //Get All Service By Id Query
   
        const result = await ServiceModel.aggregate([
    {
     
      $lookup: {
        from: "service_categorys",
        localField: "category_id",
        foreignField: "_id",
        as: "category"
      }
    },
    
    
    
  ])  
         return result        
   
}

exports.updateServiceService = async(data,id) =>{                              //Update Service By Id Query
     
        const result = await ServiceModel.findByIdAndUpdate(data,id);
          return result     
}

exports.deleteServiceService = async(id) =>{                                  //Delete Service By Id Query
     
        const result = await ServiceModel.findByIdAndDelete(id);
         return result    
}