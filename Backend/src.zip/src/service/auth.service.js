const userModel = require("../models/user.model")
const bcrypt = require('bcrypt')
const dotenv = require('dotenv');
var jwt = require('jsonwebtoken');
dotenv.config();
 const saltRounds = parseInt(process.env.SALT)
exports.registrationAuthService = async(result) => {
       const salt =await  bcrypt.genSalt(saltRounds);
       const hash =await bcrypt.hash(result.password, salt);
        result.password = hash
        const data =await userModel.create(result)           //Creat User Query
        return data  
       
}

exports.loginAuthService = async({email,password}) => {
       let user = await userModel.findOne({ email })
         if(!user) {
             return res.status(401).json({
                  message: "Please Enter Correct Credential"
                });
         }
         const userData = {
            email : user.email,
         }
      
         bcrypt.compare(password,user.password, (err,result) => {
            if(result){
               const token = jwt.sign({
                  email:user.email,
               },secret,{expiresIn: "1h"})
               return result({
                  data: userData,
                  token: token,
                  isAuthenticated: true,
                  message: "LOG IN",
                });
            }
            
         })
   
}