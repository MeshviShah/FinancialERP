const Task_statusModel = require("../models/task_status.model")

exports.CreatTask_statusService = async(data) =>{ 
        const result = await Task_statusModel.create(data);                           // Creat Task_status Query
        return result   
   
}
exports.getTask_statusService = async(id) =>{
     
        const result = await Task_statusModel.findById(id);                          //Get Task_status By Id Query
         return result         
   
}
exports.getAllTask_statusService = async() =>{
   
        const result = await Task_statusModel.find();                                //Get All Task_status Query
         return result        
   
}

exports.updateTask_statusService = async(data,id) =>{
     
        const result = await Task_statusModel.findByIdAndUpdate(data,id);           //Update Task_status By Id Query
          return result     
}

exports.deleteTask_statusService = async(id) =>{
     
        const result = await Task_statusModel.findByIdAndDelete(id);               //Delete Task_status By Id Query
         return result    
}