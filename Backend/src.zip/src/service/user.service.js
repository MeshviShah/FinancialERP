const userModel = require("../models/user.model")
 const mongoose = require('mongoose');
 const { ObjectId } = mongoose.Types;
exports.CreatUserService = async(data) =>{ 
  const salt =await  bcrypt.genSalt(saltRounds);
       const hash =await bcrypt.hash(data.password, salt);
        data.password = hash
        const result = await userModel.create(data);             //Creat User Query
        return result   
   
}
exports.getUserService = async(id) =>{                         //Fet USer By Id Query
     
        const result = await userModel.aggregate([
        {
          $match: {
            _id: new ObjectId(id)
        }
        },
   
    {
     
      $lookup: {
        from: "firms",
        localField: "firm_id",
        foreignField: "_id",
        as: "firm"
      }
    },
     {
     
      $lookup: {
        from: "roles",
        localField: "role_id",
        foreignField: "_id",
        as: "role"
      }
    },
    
    
  ])
         return result        
   
}
exports.getAllUserService = async() =>{
   
        const result = await userModel.aggregate([         //Get All User Query
   
    {
     
      $lookup: {
        from: "firms",
        localField: "firm_id",
        foreignField: "_id",
        as: "firm"
      }
    },
     {
     
      $lookup: {
        from: "roles",
        localField: "role_id",
        foreignField: "_id",
        as: "role"
      }
    },
    
    
  ])
         return result        
   
}

exports.updateUserService = async(data,id) =>{               
     
        const result = await userModel.findByIdAndUpdate(data,id);       //Update User By Id Query
          return result     
}

exports.deleteUserService = async(id) =>{
     
        const result = await userModel.findByIdAndDelete(id);            //Delete User By Id QUery
         return result    
}