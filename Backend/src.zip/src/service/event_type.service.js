const Event_TypeModel = require("../models/event_type.model")


exports.CreatEvent_TypeService = async(data) =>{ 
        const result = await Event_TypeModel.create(data);                          //Creat Event_Type Query
        return result   
   
}
exports.getEvent_TypeService = async(id) =>{
     
        const result = await Event_TypeModel.findById(id);                          //Get Event_Type By Id Query
         return result        
   
}
exports.getAllEvent_TypeService = async() =>{
   
        const result = await Event_TypeModel.find();                               //Get All Event_Type Query
         return result        
   
}

exports.updateEvent_TypeService = async(data,id) =>{
     
        const result = await Event_TypeModel.findByIdAndUpdate(data,id);          //Update Event_Type By Id Query
          return result     
}

exports.deleteEvent_TypeService = async(id) =>{
     
        const result = await Event_TypeModel.findByIdAndDelete(id);              //Delete Event_Type By ID query
         return result    
}