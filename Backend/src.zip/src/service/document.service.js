const DocumentModel = require("../models/document.model")
 const mongoose = require('mongoose');
 const { ObjectId } = mongoose.Types;

exports.CreatDocumentService = async(data) =>{ 
        const result = await DocumentModel.create(data);                          //Creat Document Query
        return result   
   
}
exports.getDocumentService = async(id) =>{
     
        const result = await DocumentModel.aggregate([
        {
          $match: {
            _id: new ObjectId(id)
        }
        },
   
    {
     
      $lookup: {
        from: "clients",
        localField: "client_id",
        foreignField: "_id",
        as: "client"
      }
    },
    {
     
      $lookup: {
        from: "services",
        localField: "service_id",
        foreignField: "_id",
        as: "service"
      }
    },
   
  
  ])                            //Get Document By Id Query
         return result        
   
}
exports.getAllDocumentService = async() =>{
   
        const result = await DocumentModel.aggregate([
   
    {
     
      $lookup: {
        from: "clients",
        localField: "client_id",
        foreignField: "_id",
        as: "client"
      }
    },
    {
     
      $lookup: {
        from: "services",
        localField: "service_id",
        foreignField: "_id",
        as: "service"
      }
    },
  ])                                    //Get All Document Query
         return result         
}

exports.updateDocumentService = async(data,id) =>{
     
        const result = await DocumentModel.findByIdAndUpdate(data,id);          //Update Document By Id Query
          return result     
}

exports.deleteDocumentService = async(id) =>{
     
        const result = await DocumentModel.findByIdAndDelete(id);              //Delete Document By ID query
         return result    
}