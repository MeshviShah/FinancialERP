const { CreatTask_statusService, getTask_statusService, getAllTask_statusService, updateTask_statusService, deleteTask_statusService } = require("../service/Task_status.service");
const {resType} = require("../response/res.types")

//Creat Task_status
exports.creatTask_statusController  = async(req,res) => {
    try{
        const data = req.body;
        const result= await CreatTask_statusService(data)
        return res.status(200).json( {data: result , res :resType.SUCCESS});    
    }catch(error){
 await res.status(500).json({error:error.message})
    }    
}
//Get Task_status By Id
exports.getTask_statusController  = async(req,res) => {
    try{
        const id = req.params.id
        const result= await getTask_statusService(id)
        return res.status(200).json( {data: result , res :resType.SUCCESS});    
    }catch(error){
 await res.status(500).json({error:error.message})
    }    
}
//Get All Task_statuss
exports.getAllTask_statusController  = async(req,res) => {
    try{
        
        const result= await getAllTask_statusService()
        return res.status(200).json( {data: result , res :resType.SUCCESS});    
    }catch(error){
 await res.status(500).json({error:error.message})
    }    
}
//Update Task_status By Id
exports.updateTask_statusController  = async(req,res) => {
    try{
        const data = req.body;
        const id = req.params.id
        const result= await updateTask_statusService(id, data)
        return res.status(200).json( {data: result , res :resType.SUCCESS});    
    }catch(error){
 await res.status(500).json({error:error.message})
    }    
}
//Delete Task_status By Id
exports.deleteTask_statusController  = async(req,res) => {
    try{
        const id = req.params.id
        const result= await deleteTask_statusService(id)
        return res.status(200).json( {data: result , res :resType.SUCCESS});    
    }catch(error){
 await res.status(500).json({error:error.message})
    }    
}
