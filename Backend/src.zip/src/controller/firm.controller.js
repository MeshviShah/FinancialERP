const { CreatFirmService, getFirmService, getAllFirmService, updateFirmService, deleteFirmService } = require("../service/Firm.service");
const {resType} = require("../response/res.types")

//creat Firm
exports.creatFirmController  = async(req,res) => {
    try{
        const data = req.body;
        const result= await CreatFirmService(data)
        return res.status(200).json( {data: result , res :resType.SUCCESS});    
    }catch(error){
 await res.status(500).json({error:error.message})
    }    
}
//get Firm By ID
exports.getFirmController  = async(req,res) => {
    try{
        const id = req.params.id
        const result= await getFirmService(id)
        return res.status(200).json( {data: result , res :resType.SUCCESS});    
    }catch(error){
 await res.status(500).json({error:error.message})
    }    
}

//get All Firm
exports.getAllFirmController  = async(req,res) => {
    try{
        
        const result= await getAllFirmService()
        return res.status(200).json( {data: result , res :resType.SUCCESS});    
    }catch(error){
 await res.status(500).json({error:error.message})
    }    
}

//Update Firm By Id
exports.updateFirmController  = async(req,res) => {
    try{
        const data = req.body;
        const id = req.params.id
        const result= await updateFirmService(id, data)
        return res.status(200).json( {data: result , res :resType.SUCCESS});    
    }catch(error){
 await res.status(500).json({error:error.message})
    }    
}

//Delete Firm By Id
exports.deleteFirmController  = async(req,res) => {
    try{
        const id = req.params.id
        const result= await deleteFirmService(id)
        return res.status(200).json( {data: result , res :resType.SUCCESS});    
    }catch(error){
 await res.status(500).json({error:error.message})
    }    
}
