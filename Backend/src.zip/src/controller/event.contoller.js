const { CreatEventService, getEventService, getAllEventService, updateEventService, deleteEventService } = require("../service/Event.service");
const {resType} = require("../response/res.types")

//Creat Event
exports.creatEventController  = async(req,res) => {
    try{
        const data = req.body;
        const result= await CreatEventService(data)
        return res.status(200).json( {data: result , res :resType.SUCCESS});    
    }catch(error){
 await res.status(500).json({error:error.message})
    }    
}
//Get Event By Id
exports.getEventController  = async(req,res) => {
    try{
        const id = req.params.id
        const result= await getEventService(id)
        return res.status(200).json( {data: result , res :resType.SUCCESS});    
    }catch(error){
 await res.status(500).json({error:error.message})
    }    
}
//Get All Events
exports.getAllEventController  = async(req,res) => {
    try{
        
        const result= await getAllEventService()
        return res.status(200).json( {data: result , res :resType.SUCCESS});    
    }catch(error){
 await res.status(500).json({error:error.message})
    }    
}
//Update Event By Id
exports.updateEventController  = async(req,res) => {
    try{
        const data = req.body;
        const id = req.params.id
        const result= await updateEventService(id, data)
        return res.status(200).json( {data: result , res :resType.SUCCESS});    
    }catch(error){
 await res.status(500).json({error:error.message})
    }    
}
//Delete Event By Id
exports.deleteEventController  = async(req,res) => {
    try{
        const id = req.params.id
        const result= await deleteEventService(id)
        return res.status(200).json( {data: result , res :resType.SUCCESS});    
    }catch(error){
 await res.status(500).json({error:error.message})
    }    
}
