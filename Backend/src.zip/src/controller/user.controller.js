const { CreatUserService, getUserService, getAllUserService, updateUserService, deleteUserService } = require("../service/user.service");
const {resType} = require("../response/res.types")

//Creat User
exports.creatUserController  = async(req,res) => {
    try{
        const data = req.body;
        const result= await CreatUserService(data)
        return res.status(200).json( {data: result , res :resType.SUCCESS});    
    }catch(error){
 await res.status(500).json({error:error.message})
    }    
}

//get User By Id 
exports.getUserController  = async(req,res) => {
    try{
        
        const id = req.params.id
        const result= await getUserService(id)
        return res.status(200).json( {data: result , res :resType.SUCCESS});    
    }catch(error){
 await res.status(500).json({error:error.message})
    }    
}
//get All Users
exports.getAllUserController  = async(req,res) => {
    try{
        
        const result= await getAllUserService()
        return res.status(200).json( {data: result , res :resType.SUCCESS});    
    }catch(error){
 await res.status(500).json({error:error.message})
    }    
}
//Update User By Id
exports.updateUserController  = async(req,res) => {
    try{
        const data = req.body;
        const id = req.params.id
        const result= await updateUserService(id, data)
        return res.status(200).json( {data: result , res :resType.SUCCESS});    
    }catch(error){
 await res.status(500).json({error:error.message})
    }    
}
//Delete User By Id
exports.deleteUserController  = async(req,res) => {
    try{
        const id = req.params.id
        const result= await deleteUserService(id)
        return res.status(200).json( {data: result , res :resType.SUCCESS});    
    }catch(error){
 await res.status(500).json({error:error.message})
    }    
}
