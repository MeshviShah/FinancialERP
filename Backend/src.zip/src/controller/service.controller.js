const { CreatServiceService, getServiceService, getAllServiceService, updateServiceService, deleteServiceService } = require("../service/service.service");
const {resType} = require("../response/res.types")

//Creat Service
exports.creatServiceController  = async(req,res) => {
    try{
        const data = req.body;
        const result= await CreatServiceService(data)
        return res.status(200).json( {data: result , res :resType.SUCCESS});    
    }catch(error){
 await res.status(500).json({error:error.message})
    }    
}

//get Service By Id 
exports.getServiceController  = async(req,res) => {
    try{
        
        const id = req.params.id
        const result= await getServiceService(id)
        return res.status(200).json( {data: result , res :resType.SUCCESS});    
    }catch(error){
 await res.status(500).json({error:error.message})
    }    
}
//get All Services
exports.getAllServiceController  = async(req,res) => {
    try{
        
        const result= await getAllServiceService()
        return res.status(200).json( {data: result , res :resType.SUCCESS});    
    }catch(error){
 await res.status(500).json({error:error.message})
    }    
}
//Update Service By Id
exports.updateServiceController  = async(req,res) => {
    try{
        const data = req.body;
        const id = req.params.id
        const result= await updateServiceService(id, data)
        return res.status(200).json( {data: result , res :resType.SUCCESS});    
    }catch(error){
 await res.status(500).json({error:error.message})
    }    
}
//Delete Service By Id
exports.deleteServiceController  = async(req,res) => {
    try{
        const id = req.params.id
        const result= await deleteServiceService(id)
        return res.status(200).json( {data: result , res :resType.SUCCESS});    
    }catch(error){
 await res.status(500).json({error:error.message})
    }    
}
