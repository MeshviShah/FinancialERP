const { CreatRoleService, getRoleService, getAllRoleService, updateRoleService, deleteRoleService } = require("../service/Role.service");
const {resType} = require("../response/res.types")

//Creat Role
exports.creatRoleController  = async(req,res) => {
    try{
        const data = req.body;
        const result= await CreatRoleService(data)
        return res.status(200).json( {data: result , res :resType.SUCCESS});    
    }catch(error){
 await res.status(500).json({error:error.message})
    }    
}
//Get Role By Id
exports.getRoleController  = async(req,res) => {
    try{
        const id = req.params.id
        const result= await getRoleService(id)
        return res.status(200).json( {data: result , res :resType.SUCCESS});    
    }catch(error){
 await res.status(500).json({error:error.message})
    }    
}
//Get All Roles
exports.getAllRoleController  = async(req,res) => {
    try{
        
        const result= await getAllRoleService()
        return res.status(200).json( {data: result , res :resType.SUCCESS});    
    }catch(error){
 await res.status(500).json({error:error.message})
    }    
}
//Update Role By Id
exports.updateRoleController  = async(req,res) => {
    try{
        const data = req.body;
        const id = req.params.id
        const result= await updateRoleService(id, data)
        return res.status(200).json( {data: result , res :resType.SUCCESS});    
    }catch(error){
 await res.status(500).json({error:error.message})
    }    
}
//Delete Role By Id
exports.deleteRoleController  = async(req,res) => {
    try{
        const id = req.params.id
        const result= await deleteRoleService(id)
        return res.status(200).json( {data: result , res :resType.SUCCESS});    
    }catch(error){
 await res.status(500).json({error:error.message})
    }    
}
