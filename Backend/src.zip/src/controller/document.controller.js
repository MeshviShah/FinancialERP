const { CreatDocumentService, getDocumentService, getAllDocumentService, updateDocumentService, deleteDocumentService } = require("../service/document.service");
const {resType} = require("../response/res.types")

//Creat Document
exports.creatDocumentController  = async(req,res) => {
    try{
        const data = req.body;
        const result= await CreatDocumentService(data)
        return res.status(200).json( {data: result , res :resType.SUCCESS});    
    }catch(error){
 await res.status(500).json({error:error.message})
    }    
}
//Get Document By Id
exports.getDocumentController  = async(req,res) => {
    try{
        const id = req.params.id
        const result= await getDocumentService(id)
        return res.status(200).json( {data: result , res :resType.SUCCESS});    
    }catch(error){
 await res.status(500).json({error:error.message})
    }    
}
//Get All Documents
exports.getAllDocumentController  = async(req,res) => {
    try{
        
        const result= await getAllDocumentService()
        return res.status(200).json( {data: result , res :resType.SUCCESS});    
    }catch(error){
 await res.status(500).json({error:error.message})
    }    
}
//Update Document By Id
exports.updateDocumentController  = async(req,res) => {
    try{
        const data = req.body;
        const id = req.params.id
        const result= await updateDocumentService(id, data)
        return res.status(200).json( {data: result , res :resType.SUCCESS});    
    }catch(error){
 await res.status(500).json({error:error.message})
    }    
}
//Delete Document By Id
exports.deleteDocumentController  = async(req,res) => {
    try{
        const id = req.params.id
        const result= await deleteDocumentService(id)
        return res.status(200).json( {data: result , res :resType.SUCCESS});    
    }catch(error){
 await res.status(500).json({error:error.message})
    }    
}
