const { CreatEvent_TypeService, getEvent_TypeService, getAllEvent_TypeService, updateEvent_TypeService, deleteEvent_TypeService } = require("../service/Event_Type.service");
const {resType} = require("../response/res.types")


//creat Event_Type
exports.creatEvent_TypeController  = async(req,res) => {
    try{
        const data = req.body;
        const result= await CreatEvent_TypeService(data)
        return res.status(200).json( {data: result , res :resType.SUCCESS});    
    }catch(error){
 await res.status(500).json({error:error.message})
    }    
}

//Get Event_Type
exports.getEvent_TypeController  = async(req,res) => {
    try{
        const id = req.params.id
        const result= await getEvent_TypeService(id)
        return res.status(200).json( {data: result , res :resType.SUCCESS});    
    }catch(error){
 await res.status(500).json({error:error.message})
    }    
}

//GEt All Event_Type
exports.getAllEvent_TypeController  = async(req,res) => {
    try{
        
        const result= await getAllEvent_TypeService()
        return res.status(200).json( {data: result , res :resType.SUCCESS});    
    }catch(error){
 await res.status(500).json({error:error.message})
    }    
}

//Update Event_Type
exports.updateEvent_TypeController  = async(req,res) => {
    try{
        const data = req.body;
        const id = req.params.id
        const result= await updateEvent_TypeService(id, data)
        return res.status(200).json( {data: result , res :resType.SUCCESS});    
    }catch(error){
 await res.status(500).json({error:error.message})
    }    
}

//Delete Event_Type
exports.deleteEvent_TypeController  = async(req,res) => {
    try{
        const id = req.params.id
        const result= await deleteEvent_TypeService(id)
        return res.status(200).json( {data: result , res :resType.SUCCESS});    
    }catch(error){
 await res.status(500).json({error:error.message})
    }    
}
