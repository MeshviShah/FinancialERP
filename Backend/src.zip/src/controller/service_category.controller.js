const { CreatService_categoryService, getService_categoryService, getAllService_categoryService, updateService_categoryService, deleteService_categoryService } = require("../service/service_category.service");
const {resType} = require("../response/res.types")

//Creat Service_category
exports.creatService_categoryController  = async(req,res) => {
    try{
        const data = req.body;
        const result= await CreatService_categoryService(data)
        return res.status(200).json( {data: result , res :resType.SUCCESS});    
    }catch(error){
 await res.status(500).json({error:error.message})
    }    
}

//get Service_category By Id 
exports.getService_categoryController  = async(req,res) => {
    try{
        
        const id = req.params.id
        const result= await getService_categoryService(id)
        return res.status(200).json( {data: result , res :resType.SUCCESS});    
    }catch(error){
 await res.status(500).json({error:error.message})
    }    
}
//get All Service_categorys
exports.getAllService_categoryController  = async(req,res) => {
    try{
        
        const result= await getAllService_categoryService()
        return res.status(200).json( {data: result , res :resType.SUCCESS});    
    }catch(error){
 await res.status(500).json({error:error.message})
    }    
}
//Update Service_category By Id
exports.updateService_categoryController  = async(req,res) => {
    try{
        const data = req.body;
        const id = req.params.id
        const result= await updateService_categoryService(id, data)
        return res.status(200).json( {data: result , res :resType.SUCCESS});    
    }catch(error){
 await res.status(500).json({error:error.message})
    }    
}
//Delete Service_category By Id
exports.deleteService_categoryController  = async(req,res) => {
    try{
        const id = req.params.id
        const result= await deleteService_categoryService(id)
        return res.status(200).json( {data: result , res :resType.SUCCESS});    
    }catch(error){
 await res.status(500).json({error:error.message})
    }    
}
