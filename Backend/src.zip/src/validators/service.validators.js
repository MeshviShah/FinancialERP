const {resType} = require("../response/res.types")

exports.serviceValidator = async(req,res,next) =>{

    const result  = req.body
    if(result.category_id && result.name)next()   
else{
    return await res.status(400).json({res : resType.VALIDAION})
}
}