const {resType} = require("../response/res.types")

exports.roleValidator = async(req,res,next) =>{

    const result  = req.body
    if(result.name)next()   
else{
    return await res.status(400).json({res : resType.VALIDAION})
}
}