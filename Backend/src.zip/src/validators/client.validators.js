const {resType} = require("../response/res.types")

exports.clientValidator = async(req,res,next) =>{

    const result  = req.body
    if(result.name && result.firm_id && result.ca_id && service_id && gst_number)next()   
else{
    return await res.status(400).json({res : resType.VALIDAION})
}
}