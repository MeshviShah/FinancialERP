const {resType} = require("../response/res.types")

exports.firmValidator = async(req,res,next) =>{

    const result  = req.body
    if(result.name && result.address && result.phone)next()   
else{
    return await res.status(400).json({res : resType.VALIDAION})
}
}