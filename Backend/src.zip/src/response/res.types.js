exports.resType = {
    SUCCESS:"success",
    ERROR:"error",
    VALIDAION:"Validation Failed",
    BAD_REQUEST: 'Oops! Something went wrong. Please try again later.',

}